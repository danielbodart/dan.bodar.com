KeyBoard Layout Switcher

What does it do?
	Allow you to switch between "Resharper + Visual Studio" and IntelliJ shortcuts

Why would you do that?
	You are pairing with someone who knows the other set of shortcuts

How to install?
	* Close Visual Studio
	* Run install.cmd from a drive (mapped if a network share) to copy the files to the default locations
	* Open Visual Studio
	* Tools - Macros - Load Macros Project... Select the ThoughtWorks folder Select the ThoughtWorks Project
	* Tools -  Options - Environment - Keyboard: Select the Resharper or IntelliJ

How to switch?
	* To switch to IntelliJ Layout press Ctrl-Shift-Alt-I
	* To switch to Resharper 4 Layout press Ctrl-Shift-Alt-R

It still does not work...
	* Tools - Options - Environment - Keyboard: Select the IntelliJ
	* Tools - Import and Export Settings... - Import selected environment settings - No, just import new settings - Browse - Select Switch.Shortcuts
	* Tools - Options - Environment - Keyboard: Select the Resharper
	* Tools - Import and Export Settings... - Import selected environment settings - No, just import new settings - Browse - Select Switch.Shortcuts

Can't you create a decent installer?
	I plan to but it looks like I might need to get my code signed by MS!

