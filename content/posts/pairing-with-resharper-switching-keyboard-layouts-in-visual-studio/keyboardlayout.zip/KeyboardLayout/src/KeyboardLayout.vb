Imports System
Imports EnvDTE
Imports EnvDTE80
Imports EnvDTE90
Imports System.Diagnostics

Public Module KeyboardLayout
    Sub SetIntelliJ()
        SetScheme("IntelliJ")
    End Sub

    Sub SetDefault()
        SetScheme("(Default)")
    End Sub

    Sub SetResharper()
        SetScheme("Resharper")
    End Sub

    Sub SetScheme(ByVal scheme)
        Dim props As EnvDTE.Properties = DTE.Properties("Environment", "Keyboard")
        Dim prop As EnvDTE.Property

        prop = props.Item("SchemeName")
        prop.Value = scheme
    End Sub
End Module

